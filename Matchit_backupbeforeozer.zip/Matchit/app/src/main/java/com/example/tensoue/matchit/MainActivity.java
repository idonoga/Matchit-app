package com.example.tensoue.matchit;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.graphics.Bitmap;
import android.media.MediaCas;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.se.omapi.Session;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Base64;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.Profile;
import com.facebook.appevents.AppEventsLogger;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FacebookAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import org.json.JSONObject;

import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    FirebaseStorage storage;
    StorageReference storageReference;



    CallbackManager mCallbackManager;

    String nickname;

    Uri filePath;

    final int PICK_IMAGE_REQUEST = 1;

    Button btn_register;
    Button btn_login;
    Button btn_signout;
    Button reg_btn_upload;

    TextView tv_Loggeduser;

    EditText login_et_email;
    EditText login_et_password;
    EditText reg_et_email;
    EditText reg_et_password;
    EditText reg_et_nickname;

    ImageView reg_iv_profilePic;

    FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
    FirebaseAuth.AuthStateListener authStateListener;


    private void AfterLoginActivity(){
        Intent intent = new Intent (getApplicationContext(),AfterLoginScreen.class);
        intent.putExtra("nickname",nickname);
        startActivity(intent);
    }

    private void chooseImage() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
    }

    private void uploadImage(){

        if(filePath != null)
        {

            final ProgressDialog progressDialog = new ProgressDialog(this);
            progressDialog.setTitle("Uploading...");
            progressDialog.show();
            final String userUUID = firebaseAuth.getCurrentUser().getUid().toString();
            final StorageReference ref = storageReference.child("images/" + userUUID);
            ref.putFile(filePath).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    progressDialog.dismiss();

                    ref.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                        @Override
                        public void onSuccess(Uri uri) {
                            scoreboardRow row = new scoreboardRow(userUUID,firebaseAuth.getCurrentUser().getDisplayName(),uri.toString());
                            Methods.createNewUserRecord(row);
                            AfterLoginActivity();
                            Toast.makeText(MainActivity.this, "Image uploaded", Toast.LENGTH_SHORT).show();
                        }
                    });


                }
            })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            progressDialog.dismiss();
                            Toast.makeText(MainActivity.this, "Failed" + e.getMessage(), Toast.LENGTH_SHORT).show();

                        }
                    })
                    .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                            double progress = (100.0*taskSnapshot.getBytesTransferred()/taskSnapshot.getTotalByteCount());
                            progressDialog.setMessage("Uploaded " + (int)progress+"%");

                        }
                    });
        }

    }

    private void handleFacebookAccessToken(AccessToken token) {


        AuthCredential credential = FacebookAuthProvider.getCredential(token.getToken());
        firebaseAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            String username = firebaseAuth.getCurrentUser().getDisplayName();
                            Toast.makeText(MainActivity.this, username + " Has signed in", Toast.LENGTH_SHORT).show();
                            FirebaseUser user = firebaseAuth.getCurrentUser();
                            tv_Loggeduser.setText(user.getDisplayName());
                            boolean isNewUser = task.getResult().getAdditionalUserInfo().isNewUser();
                            if(isNewUser){
                                Log.e("GEVER","Newfacebookuser");
                                String picString = "https://graph.facebook.com/" + Profile.getCurrentProfile().getId() + "/picture?width=200&height=200";
                                scoreboardRow row = new scoreboardRow(user.getUid(),user.getDisplayName(), picString);
                                Methods.createNewUserRecord(row);
                            }

                        } else {
                            // If sign in fails, display a message to the user.

                            Toast.makeText(MainActivity.this, "Authentication failed.",
                                    Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        mCallbackManager.onActivityResult(requestCode, resultCode,data);
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null){
            filePath = data.getData();
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath);
                reg_iv_profilePic.setImageBitmap(bitmap);
                reg_iv_profilePic.setVisibility(View.VISIBLE);
            }
            catch (IOException e){
                e.printStackTrace();
            }

        }


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.action_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == R.id.action_signout) {
            Methods.signOut();
        }
        else if (item.getItemId() == R.id.action_scoreboard){

        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        mCallbackManager = CallbackManager.Factory.create();
        LoginButton btn_facebook_login = findViewById(R.id.btn_facebook_login);
        btn_facebook_login.setReadPermissions("email", "public_profile");

        LoginManager.getInstance().registerCallback(mCallbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {
                /////////////////////GET FACEBOOK INFORMATION/////////////////////
//                GraphRequest request = GraphRequest.newMeRequest(loginResult.getAccessToken(), new GraphRequest.GraphJSONObjectCallback() {
//                    @Override
//                    public void onCompleted(JSONObject object, GraphResponse response) {
//                        try {
//                            Log.v("FACEBOOK LOGIN", response.toString());
//                            String fb_id = object.getString("id");   //FaceBook User ID
//                            String fb_name = object.getString("name");
//                            String fb_email = object.getString("email");
//                            String profilePicUrl = "https://graph.facebook.com/" + fb_id + "/picture?width=200&height=200";
//                        } catch (Exception e) {
//                            e.printStackTrace();
//                        }
//                    }
//                });
//                Bundle parameters = new Bundle();
//                parameters.putString("fields", "id,name,email,picture.type(small)");
//                request.setParameters(parameters);
//                request.executeAsync();

                handleFacebookAccessToken(loginResult.getAccessToken());




            }

            @Override
            public void onCancel() {
                Toast.makeText(MainActivity.this, "Cancel Login with facebook", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onError(FacebookException error) {
                Toast.makeText(MainActivity.this, "Error logging in with facebook", Toast.LENGTH_SHORT).show();

            }
        });


        btn_register = findViewById(R.id.btn_register);
        btn_login = findViewById(R.id.btn_login);
        btn_signout = findViewById(R.id.btn_signout);

        tv_Loggeduser = findViewById(R.id.tv_loggedUser);

        login_et_email = findViewById(R.id.et_email);
        login_et_password = findViewById(R.id.et_password);




        btn_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Inflating the dialog and getting the inputs//
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                View dialogView = getLayoutInflater().inflate(R.layout.register_dialog,null);
                reg_et_email = dialogView.findViewById(R.id.reg_et_email);
                reg_et_password = dialogView.findViewById(R.id.reg_et_password);
                reg_et_nickname = dialogView.findViewById(R.id.reg_et_nickname);
                reg_btn_upload = dialogView.findViewById(R.id.reg_btn_upload);
                reg_iv_profilePic = dialogView.findViewById(R.id.reg_iv_profilePic);
                storage = FirebaseStorage.getInstance();
                storageReference = storage.getReference();

                reg_btn_upload.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        chooseImage();

                    }
                });

                //Registered button methods//
                builder.setView(dialogView).setPositiveButton("Register", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        final String reg_email = reg_et_email.getText().toString();
                        String reg_password = reg_et_password.getText().toString();
                        nickname = reg_et_nickname.getText().toString();
                        Toast.makeText(MainActivity.this, reg_email + " " + reg_password, Toast.LENGTH_SHORT).show();
                        //register the user//
                        firebaseAuth.createUserWithEmailAndPassword(reg_email,reg_password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if(task.isSuccessful()) {
                                    Toast.makeText(MainActivity.this, "User" + nickname + "has Signed up", Toast.LENGTH_SHORT).show();
                                    //uploadImage();
                                }
                                else
                                    Toast.makeText(MainActivity.this, "Register failed", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                }).show();
            }
        });

                btn_login.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        final String email = login_et_email.getText().toString();
                        String password = login_et_password.getText().toString();
                        if(email != null && password != null) {
                            //signin in the user//
                            firebaseAuth.signInWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if (task.isSuccessful())
                                        Toast.makeText(MainActivity.this, "User" + email.toString() + "has signed in successfully", Toast.LENGTH_SHORT).show();
                                    else
                                        Toast.makeText(MainActivity.this, "Sign in failed", Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                        else if (email == null || password == null)
                            Toast.makeText(MainActivity.this, "Please enter all the values", Toast.LENGTH_SHORT).show();


                    }
                });


                btn_signout.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if(AccessToken.getCurrentAccessToken() == null)
                            firebaseAuth.signOut();
                        else
                            LoginManager.getInstance().logOut();
                    }
                });




        //On every auth status change//
        authStateListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if (user != null){
                    if(nickname != null){  //user has just been registered
                        user.updateProfile(new UserProfileChangeRequest.Builder().setDisplayName(nickname).build()).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful())
                                    Toast.makeText(MainActivity.this, "Welcome" + nickname, Toast.LENGTH_SHORT).show();
                            }
                        });
                        nickname = user.getDisplayName();

                        uploadImage();
                            //AfterLoginActivity();

                        tv_Loggeduser.setText(nickname + " logged in");



                    }
                    else {
                        nickname = user.getDisplayName();
                        tv_Loggeduser.setText(nickname + " logged in");
                        AfterLoginActivity();
                    }

                }
                else {
                    tv_Loggeduser.setText("Please log in");

                }
            }
        };


    }


    @Override
    protected void onStart() {
        super.onStart();

        firebaseAuth.addAuthStateListener(authStateListener);
    }

    @Override
    protected void onStop() {
        super.onStop();
        firebaseAuth.removeAuthStateListener(authStateListener);
    }





}
