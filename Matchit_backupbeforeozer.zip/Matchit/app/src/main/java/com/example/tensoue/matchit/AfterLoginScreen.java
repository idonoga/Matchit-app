package com.example.tensoue.matchit;


import com.bumptech.glide.Glide;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Handler;
import android.provider.MediaStore;
import android.service.autofill.FieldClassification;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.MenuCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.request.animation.GlideAnimation;
import com.bumptech.glide.request.target.SimpleTarget;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.Profile;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.firebase.ui.database.FirebaseListAdapter;
import com.firebase.ui.storage.images.FirebaseImageLoader;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import org.json.JSONObject;

import java.io.IOException;
import java.lang.reflect.Type;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class AfterLoginScreen extends AppCompatActivity {

    String nickname;
    TextView tv_welcome;
    ImageView iv_profilePic;
    Bitmap profilePic;
    FirebaseStorage storage = FirebaseStorage.getInstance();
    FirebaseAuth firebaseAuth;
    FirebaseUser firebaseUser = firebaseAuth.getInstance().getCurrentUser();
    CallbackManager mCallbackManager;
    final FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference ref = database.getReferenceFromUrl("https://matchit-8abc0.firebaseio.com/");



    private void setProfilePic(){

        if(firebaseUser.getProviders().toString().contains("facebook")) {
            String fb_profilePic = "https://graph.facebook.com/" + Profile.getCurrentProfile().getId() + "/picture?width=200&height=200";
            Glide
                    .with(getApplicationContext())
                    .load(fb_profilePic)
                    .asBitmap()
                    .into(new SimpleTarget<Bitmap>(300,300) {
                        @Override
                        public void onResourceReady(Bitmap resource, GlideAnimation glideAnimation) {
                            iv_profilePic.setImageBitmap(resource);
                        }
                    });
        }

        else {
            String userUUID = firebaseUser.getUid().toString();
            StorageReference profilePicRef = storage.getReference().child(("images/" + userUUID));

            Glide.with(AfterLoginScreen.this)
                    .using(new FirebaseImageLoader())
                    .load(profilePicRef)
                    .override(300, 300)
                    .into(iv_profilePic);
        }
        iv_profilePic.setVisibility(View.VISIBLE);
    }

    private void sendToFirstScreen(){
        Intent intent = new Intent (getApplicationContext(),MainActivity.class);
        startActivity(intent);
    }
    private void signOutDialog(){
        AlertDialog.Builder builder = new AlertDialog.Builder(AfterLoginScreen.this);
        builder.setMessage("Are you sure you want to sign out?").setTitle("Sign out");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Methods.signOut();
                sendToFirstScreen();
            }
        }).show();
        AlertDialog dialog = builder.create();

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == R.id.action_signout) {
            signOutDialog();



        }
        else if (item.getItemId() == R.id.action_scoreboard){
//            android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(AfterLoginScreen.this);
//            View dialogView = getLayoutInflater().inflate(R.layout.scoreboard_dialog,null);
//            ListView lv_scoreboard = dialogView.findViewById(R.id.lv_scoreboard);
//
//            android.app.AlertDialog.Builder scoreboardDialog = new android.app.AlertDialog.Builder(this);
//            scoreboardDialog.setView(dialogView);
//            Methods.showScoreboard(lv_scoreboard);
//            scoreboardDialog.show();
            //tabbed dialog
            FragmentManager fm = getSupportFragmentManager();
            ListView lv_scoreboard = findViewById(R.id.lv_scoreboard);
            TabbedDialog dialog = new TabbedDialog(lv_scoreboard);
            dialog.show(fm,"Dialog");
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.action_menu,menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        final  Typeface font = Typeface.createFromAsset(getAssets(),"fonts/Simplehandwritting-Regular.ttf");
        setContentView(R.layout.activity_after_login_screen);
        final ViewGroup afterLoginLayout = findViewById(R.id.layout_afterloginscreen);
        Methods.setFont(afterLoginLayout,font);
        tv_welcome = findViewById(R.id.tv_welcome);
        iv_profilePic = findViewById(R.id.iv_profilePicAfterLogin);
        Button btn_solo = findViewById(R.id.btn_solo);
        Button btn_multi = findViewById(R.id.btn_multi);


        Intent intent = getIntent();
        nickname = intent.getStringExtra("nickname");
//        setProfilePic();
        Methods.setProfilePicMethod(iv_profilePic);
        tv_welcome.setText("Welcome " + nickname);

        btn_solo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(AfterLoginScreen.this);
                View dialogView = getLayoutInflater().inflate(R.layout.startgame_dialog,null);

                Button btn_easy = dialogView.findViewById(R.id.btn_easy);
                Button btn_medium = dialogView.findViewById(R.id.btn_medium);
                Button btn_hard = dialogView.findViewById(R.id.btn_hard);
               // TextView tv_startgame = findViewById(R.id.start_text);

                //tv_startgame.setTypeface(font);
                btn_easy.setTypeface(font);
                btn_medium.setTypeface(font);
                btn_hard.setTypeface(font);

                TextView dialogStartGameTV = new TextView(AfterLoginScreen.this);
                dialogStartGameTV.setTypeface(font);
                dialogStartGameTV.setGravity(Gravity.CENTER);
                dialogStartGameTV.setText("Start Game");
                dialogStartGameTV.setTextSize(20);
                dialogStartGameTV.setPadding(10,10,10,10);
                builder.setView(dialogView).setCustomTitle(dialogStartGameTV).show().getWindow().setLayout(500,650);




            }
        });





        //testing database

//        DatabaseReference scoreboardRef = ref.child("scoreboard_hard").child(firebaseUser.getUid());
//        Map<String,scoreboardRow> scoreboardMap = new HashMap<>();
//        scoreboardMap.put(firebaseUser.getUid(), new scoreboardRow(firebaseUser.getUid(),firebaseUser.getDisplayName(),100,Methods.getUserProfilePic()));
//                scoreboardRef.setValue(new scoreboardRow(firebaseUser.getUid(),firebaseUser.getDisplayName(),100,Methods.getUserProfilePic()));
    }
}
