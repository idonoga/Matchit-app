package com.example.tensoue.matchit;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.media.Image;
import android.net.Uri;
import android.service.autofill.FieldClassification;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.animation.GlideAnimation;
import com.bumptech.glide.request.target.BitmapImageViewTarget;
import com.bumptech.glide.request.target.SimpleTarget;
import com.bumptech.glide.request.target.Target;
import com.facebook.Profile;
import com.firebase.ui.database.FirebaseListAdapter;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.facebook.login.LoginManager;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Methods {



    ////////////////NEED TO CHANGE THIS!!//////////////
    public static void setProfilePicMethod(final ImageView iv){

        if(FirebaseAuth.getInstance().getCurrentUser().getProviders().toString().contains("facebook")) {
            String fb_profilePic = "https://graph.facebook.com/" + Profile.getCurrentProfile().getId() + "/picture?width=200&height=200";
            Glide
                    .with(Matchit.getAppContext())
                    .load(fb_profilePic)
                    .asBitmap()
                    .into(new SimpleTarget<Bitmap>(300,300) {
                        @Override
                        public void onResourceReady(Bitmap resource, GlideAnimation glideAnimation) {
                            iv.setImageBitmap(resource);
                        }
                    });
        }


        else {
            String userUUID = FirebaseAuth.getInstance().getCurrentUser().getUid().toString();
            StorageReference profilePicRef = FirebaseStorage.getInstance().getReference().child(("images/" + userUUID));

            Glide.with(Matchit.getAppContext())
                    .using(new com.firebase.ui.storage.images.FirebaseImageLoader())
                    .load(profilePicRef)
                    .override(300, 300)
                    .into(iv);
        }
        iv.setVisibility(View.VISIBLE);
    }


    public static void setFont(ViewGroup group, Typeface font) {
        int count = group.getChildCount();
        View v;
        for (int i = 0; i < count; i++) {
            v = group.getChildAt(i);
            if (v instanceof TextView || v instanceof EditText || v instanceof Button) {
                ((TextView) v).setTypeface(font);
            } else if (v instanceof ViewGroup)
                setFont((ViewGroup) v, font);
        }
    }


    public static void setProfilePicMethod(final ImageView iv, final String picString){
                Glide
                        .with(Matchit.getAppContext())
                        .load(picString)
                        .asBitmap()
                        .centerCrop()
                        .diskCacheStrategy(DiskCacheStrategy.SOURCE)
                        .into(new SimpleTarget<Bitmap>(200,150) {
                            @Override
                            public void onResourceReady(Bitmap resource, GlideAnimation glideAnimation) {
                                iv.setImageBitmap(resource);
                            }
                        });

                iv.setVisibility(View.VISIBLE);
    }


    public static String getUserProfilePic(){

         final String userProfilePic;

        if(FirebaseAuth.getInstance().getCurrentUser().getProviders().toString().contains("facebook")) {
            userProfilePic = "https://graph.facebook.com/" + Profile.getCurrentProfile().getId() + "/picture?width=200&height=200";
            return userProfilePic;
        }


        else {
            String userUUID = FirebaseAuth.getInstance().getCurrentUser().getUid().toString();
            StorageReference profilePicRef = FirebaseStorage.getInstance().getReference().child(("images/" + userUUID));
            userProfilePic = profilePicRef.getDownloadUrl().toString();
        }
            return userProfilePic;

    }


    public static void createNewUserRecord(scoreboardRow row)
    {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference ref = database.getReferenceFromUrl("https://matchit-8abc0.firebaseio.com/");
        DatabaseReference scoreboardRef = ref.child("users").child(row.getUserUUID());
//        DatabaseReference newRef = scoreboardRef.push();
        scoreboardRef.setValue(row);
    }

    public static void showScoreboard(final ListView lv_scoreboard,String level){
        Log.e("GEVER","on scoreboard");
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference dbRef = database.getReferenceFromUrl("https://matchit-8abc0.firebaseio.com/").child("scoreboard_"+level);
        dbRef.orderByChild("highestScore").limitToLast(100).startAt(1).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                List<scoreboardRow> list = new ArrayList<>();
                for(DataSnapshot unit : dataSnapshot.getChildren()){
                    scoreboardRow row = unit.getValue(scoreboardRow.class);
                    list.add(row);

                }

//                Log.e("GEVER",String.valueOf(list.get(0).getHighestScore()));
                customListViewAdapter adapter = new customListViewAdapter(Matchit.getAppContext(),R.layout.lv_rowitem,list);
                lv_scoreboard.setAdapter(adapter);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
//        dbRef.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(DataSnapshot dataSnapshot) {
//                List<scoreboardRow> list = new ArrayList<>();
//                for(DataSnapshot unit : dataSnapshot.getChildren()){
//                    scoreboardRow row = unit.getValue(scoreboardRow.class);
//                    list.add(row);
//                }
//
//                Log.e("GEVER",String.valueOf(list.get(0).getHighestScore()));
//                customListViewAdapter adapter = new customListViewAdapter(Matchit.getAppContext(),R.layout.lv_rowitem,list);
//                lv_scoreboard.setAdapter(adapter);
//
//            }
//            @Override
//            public void onCancelled(DatabaseError databaseError) {
//
//            }
//        });
    }




    public static void signOut(){
        FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
//        if(AccessToken.getCurrentAccessToken() == null)
            firebaseAuth.signOut();
            LoginManager.getInstance().logOut();
//        else
//            LoginManager.getInstance().logOut();

    }

}
