package com.example.tensoue.matchit;

import android.app.Dialog;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.DialogFragment;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ListView;
import android.widget.TabWidget;
import android.widget.TableLayout;


public class TabbedDialog extends DialogFragment {


        TabLayout tabLayout;
    ViewPager viewPager;
    ListView lv_scoreboard;
    public TabbedDialog(){}
    public TabbedDialog(ListView lv_scoreboard) {
        this.lv_scoreboard = lv_scoreboard;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View rootview = inflater.inflate(R.layout.tabbed_dialog,container,false);
        tabLayout = (TabLayout) rootview.findViewById(R.id.tabLayout);
        viewPager = (ViewPager) rootview.findViewById(R.id.masterViewPager);
        tabbedDialogAdapter adapter = new tabbedDialogAdapter(getChildFragmentManager());
        adapter.addFragment("Easy",tabFragment.createInstance(lv_scoreboard,"easy"));
        adapter.addFragment("Medium",tabFragment.createInstance(lv_scoreboard,"medium"));
        adapter.addFragment("Hard",tabFragment.createInstance(lv_scoreboard,"hard"));
        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);
        return rootview;
    }
}
